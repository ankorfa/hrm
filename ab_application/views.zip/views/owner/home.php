<!--=== Content ===-->
<div class="container content">
    <div class="row category margin-bottom-20">
        <div class="col-sm-6 md-margin-bottom-50">
            <div class="headline"><h2>For Bus owner</h2></div>
            Page Details
        </div>
    </div><!--/category-->
</div><!--/container-->
<!--=== End Content ===-->
