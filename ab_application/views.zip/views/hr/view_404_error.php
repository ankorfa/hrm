<div class="col-md-10 main-content-div">
    <div class="main-content">

         <!--=== Breadcrumbs ===-->
        <div class="breadcrumbs">
            <div class="container">
                <h1 class="pull-left">404 Error</h1>
            </div>
        </div><!--/breadcrumbs-->
        <!--=== End Breadcrumbs ===-->

        <!--=== Content Part ===-->
        <div class="container content">
            <!--Error Block-->
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="error-v1">
                                            <h2>
                        <span class="error-v1-title">404</span>
                        <span>That’s an error!</span>
                                            </h2>
                        <p>The requested URL was not found on this server. That’s all we know.</p>
                        <a  href="<?php echo base_url() . 'Con_dashbord' ?>" class="btn-u btn-bordered">Back Home</a>
                       	
                    </div>
                </div>
            </div>
            <!--End Error Block-->
        </div>
        <!--=== End Content Part ===-->

    </div>
</div>

</div><!--/row-->
</div><!--/container-->

