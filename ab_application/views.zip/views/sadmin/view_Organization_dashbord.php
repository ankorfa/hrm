

<div class="col-md-10 main-content-div">
    <div class="main-content">
        
        <div class="container conbre">
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url() . 'con_Module' ?>">HRM</a></li>
                <li class="active"><?php echo $page_header; ?></li>
            </ol>
        </div>
        <div class="container tag-box tag-box-v3" style="margin-top:0px; padding-bottom: 15px;">
         
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header text-center">
                         <small> Organization Setup. </small>
                    </h2>
                </div>
            </div>
           
        </div>

    </div>
</div>
		 
    </div><!--/end row-->
</div><!--/end container-->
