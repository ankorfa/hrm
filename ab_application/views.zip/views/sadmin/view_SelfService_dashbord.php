<style>
.datepicker-inline {
    width: 100% !important;
    height: 100% !important;
}


div.datepicker-days > table{
    width: 100% !important;
    height: 100% !important;
    font-size:1.5em;
}

div.datepicker-days > table thead tr{
     font-size: 24px !important;
}

div.datepicker-days > table tbody tr{
    height:60px;
}

.activeClass{
    /*background: #ffcc00;*/ 
    /*background: #72c02c;*/ 
    
    background: #b4e391; /* Old browsers */
    background: -moz-linear-gradient(top, #b4e391 0%, #61c419 50%, #b4e391 100%); /* FF3.6-15 */
    background: -webkit-linear-gradient(top, #b4e391 0%,#61c419 50%,#b4e391 100%); /* Chrome10-25,Safari5.1-6 */
    background: linear-gradient(to bottom, #b4e391 0%,#61c419 50%,#b4e391 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b4e391', endColorstr='#b4e391',GradientType=0 ); /* IE6-9 */
   
  }
  

</style>

<div class="col-md-10 main-content-div">
    <div class="main-content">

        <div class="container conbre">
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url() . 'Con_SelfService' ?>">HRM</a></li>
                <li class="active"><?php echo $page_header; ?></li>
            </ol>
        </div>
        
        <div class="container tag-box tag-box-v3" style="margin-top:0px; width: 96%; padding-bottom: 15px;">
            
            <div class="tab-pane fade in active" id="home-1">
                <form action="#" id="sky-form" class="sky-form">
                    <fieldset>
                        <section>
                            <div id="inline"></div>
                        </section>

                    </fieldset>
                </form>
            </div>
            
        </div>
        <?php if ($user_group == 10){ ?>
        <div class="container tag-box tag-box-v3" style="margin-top:0px; padding-bottom: 15px;">
            <div class="container col-md-12">
                <div class="col-md-12">
                    <div align="center" id="container_chart"></div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

<style type="text/css">
    #container_chart{min-width:410px !important; width:100% !important; height:400px !important; margin:0 auto !important}
    .highcharts-credits{display:none !important}
</style>

<?php
if ($user_group == 10) {
    
    //$user_id
    $emp_id= $this->Common_model->get_selected_value($this,'emp_user_id',$user_id,'main_employees','employee_id');
    
    $this->db->select("main_leave_transaction.leave_type, SUM(`number_of_days`) AS consumed_days, main_leave_policy.max_limit, leave_code, leave_short_code");
    $this->db->join("main_leave_policy", "main_leave_policy.leave_type = main_leave_transaction.leave_type");
    $this->db->join("main_employeeleavetypes", "main_employeeleavetypes.id = main_leave_policy.leave_type");
    $this->db->where("main_leave_transaction.employee_id=$emp_id");
    $this->db->group_by("main_leave_transaction.leave_type");
    $chart_data = $this->db->get("main_leave_transaction")->result_array();
//    echo $this->db->last_query();

    //pr($chart_data);
}
?>
<script src="<?php echo base_url(); ?>assets/chart/hschart/highcharts.js"></script>

<script type="text/javascript">
<?php if ($user_group == 10) { ?>

        Highcharts.chart('container_chart', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Leave Type wise Allocated and Consumed Leave Days'
            },
            xAxis: {
                categories: [
    <?php
    if (!empty($chart_data)) {
        $pieces = array();
        foreach ($chart_data as $value) {
            $pieces[] = "'" . $value['leave_code'] . "'";
        }
        echo implode(',', $pieces);
    }
    ?>
                ],
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Number of Day(s)'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">Leave Type: {point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0"> {series.name}(s) : </td>' +
                        '<td style="padding:0"><b>{point.y:,.0f}</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [
    <?php
    if (!empty($chart_data)) {
        $total_leave = $total_consumed = $balance = array();

        foreach ($chart_data as $row) {
            $total_leave[] = $row['max_limit'];
            $consumed_leave[] = $row['consumed_days'];
            $balance_leave[] = ($row['max_limit'] - $row['consumed_days']);
        }

        echo "{
                color: '#95CEFF',
                name: 'Allocated Leave',
                data: [" . implode(',', $total_leave) . "]";
        echo "},{
                color: '#FFBC75',
                name: 'Consumed Leave',
                data: [" . implode(',', $consumed_leave) . "]";
        echo "},{
                color: '#72C02C',
                name: 'Remaining Leave',
                data: [" . implode(',', $balance_leave) . "]";
        echo "}";
    }
    ?>
            ]
        });

<?php } ?>
</script>

<?php
if ($user_group == 10) {
    
    $emp_id=$this->Common_model->get_selected_value($this,'emp_user_id',$this->user_id,'main_employees','employee_id');
    
    $this->db->order_by("number_of_days","desc");
    $query = $this->db->get_where('main_leave_request', array('isactive' => 1,'leave_status' => 1,'employee_id' => $emp_id ));
    //echo $this->db->last_query();
    
    $fn_date="";
    $leave_date="";
    $lleave="";
    if ($query) {
        foreach ($query->result() as $row) {
            
            if($row->number_of_days>1)
            {
                for ($x = 0; $x < $row->number_of_days; $x++) {
                   //echo $x."=="."<br>";
                   if($lleave=="")
                   {
                       $ddate=$this->Common_model->add_date($row->from_date,$x);
                       $lleave='"' .date("n-j-Y",strtotime($ddate)). '"';
                   }
                   else
                   {
                       $ddate=$this->Common_model->add_date($row->from_date,$x);
                       $lleave=$lleave.",".'"' .date("n-j-Y",strtotime($ddate)). '"';
                   }
                } 
            }
            else {
                    $lleave='"' .date("n-j-Y",strtotime($row->from_date)). '"';
//                if($leave_date=="") $leave_date='"' .date("n-j-Y",strtotime($row->from_date)). '"';
//                else $leave_date=$leave_date.",". '"' .date("n-j-Y",strtotime($row->from_date)). '"';
            }
            
            if($fn_date==""){ $fn_date=$lleave; } else {$fn_date=$fn_date.",".$lleave; }
        }
  
    }
    
    //echo $fn_date;
    //echo $lleave;
    //echo $leave_date;
}
?>
<script type="text/javascript">

    
    var active_dates = [<?php  echo $fn_date; ?>];
    //var active_dates = ["5-11-2017"];
    
    jQuery(document).ready(function() {
        
        $('#inline').datepicker({
            format: 'mm-dd-yyyy',
            todayHighlight: true,
            autoclose: true,
            beforeShowDay: function(date){
                    var d = date;
                    var curr_date = d.getDate();
                    var curr_month = d.getMonth() + 1; //Months are zero based
                    var curr_year = d.getFullYear();
                    var formattedDate = curr_month + "-" + curr_date + "-" + curr_year
                    //alert (formattedDate);
                    if ($.inArray(formattedDate, active_dates) != -1){
                      return {
                         classes: 'activeClass'
                      };
                    }
                 return;
             }
        }).on('changeDate', showTestDate);
        
        function showTestDate(){
            var tdate = $('#inline').datepicker('getFormattedDate');
            //alert (tdate);
//            $.ajax({
//                url: "<?php //  echo site_url('Con_Training/ajax_training_Modal/') ?>/" + tdate,
//                type: "POST"
//            }).done(function (data) {
//                //alert(data);
//                $('#training_req').html(data);
//                
//                $('#Coy_Modal').modal('show'); // show bootstrap modal when complete loaded
//                $('.modal-title').text('Training Status'); // Set title to Bootstrap modal title
//            });
        }

    });
    

    
</script>

</div><!--/end row-->
</div><!--/end container-->
