<!--=== Footer Version 1 ===-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.12.1.min.js"></script>

<!-- JS Global Compulsory -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>

<!-- Log-in -->
<script src="<?php echo base_url(); ?>assets/js/login.js"></script>

<!--<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/custom.js"></script>-->

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/vegas.js"></script>


    

<script>
    $(function() {
        $('body').vegas({
            preload: true,
            transition: 'swirlLeft2',
            transitionDuration: 20000,
            delay: 5000,
            slides: [
                { src: '<?php echo base_url(); ?>assets/img/login_bg/slider-img1.jpg' },
                { src: '<?php echo base_url(); ?>assets/img/login_bg/slider-img2.jpg',transition: 'zoomIn', },
                { src: '<?php echo base_url(); ?>assets/img/login_bg/slider-img3.jpg',transition: 'zoomOut', },
                { src: '<?php echo base_url(); ?>assets/img/login_bg/slider-img4.jpg',transition: 'zoomOut', },
                { src: '<?php echo base_url(); ?>assets/img/login_bg/slider-img5.jpg',transition: 'zoomOut', }
            ]
        });
    });
    
</script>


</body>
</html>