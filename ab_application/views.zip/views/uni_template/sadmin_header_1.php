<?php
    $log_data = $this->session->userdata('logged_in'); 
    $username=$log_data['name'];
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
    <head>
        <title><?php echo $title; ?></title>

        <!-- Meta -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- Favicon -->
	<link rel="icon" type="image/ico" href="<?php echo base_url(); ?>assets/img/icon.ico"/>
        
        <!-- Web Fonts -->
        <link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

        <!-- CSS Global Compulsory -->
        <link rel="stylesheet"  href="<?php echo base_url(); ?>assets/plugins/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">

        <!-- CSS Header and Footer -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/headers/header-default.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/footers/footer-v1.css">
          
        <!-- CSS Implementing Plugins -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/animate.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/line-icons/line-icons.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/font-awesome/css/font-awesome.min.css">
        <!--<link rel="stylesheet" href="assets/plugins/owl-carousel/owl-carousel/owl.carousel.css">-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css">
        <!--[if lt IE 9]><link rel="stylesheet" href="assets/plugins/sky-forms-pro/skyforms/css/sky-forms-ie8.css"><![endif]-->

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/hover-effects/css/custom-hover-effects.css">

        <!-- CSS Page Style -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/pages/page_search.css">

        <!-- CSS Theme -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/theme-colors/default.css" id="style_color">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/theme-skins/dark.css">

        <!-- CSS Customization -->
       
        <link href="<?php echo base_url(); ?>assets/css/select2.css" rel="stylesheet"/>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/image-hover/css/img-hover.css">
        <!-- CSS log-in -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/login.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/magic/magic.css" />
        <!-- data table -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/dataTables/dataTables.bootstrap.css" />
        <!-- JS -->
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/sky-forms-pro/skyforms/js/jquery.validate.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/validation.js"></script>
        <!-- select 2 -->
        <script src="<?php echo base_url(); ?>assets/js/select2.js"></script> 
        <!-- Time Picker-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/timepicker/bootstrap-timepicker.css" type="text/css" media="screen">
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/timepicker/bootstrap-timepicker.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.chained.min.js"></script> 
        
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/custom.css">
        
        
    </head>
    <body class="">
        <div class="wrapper">
            <!--=== Header ===-->
            <div class="header">
                <div class="top-bar">
                    <div class="container">
                        <div class="row ">
                        
                            <div class="col-md-6">
                                <!-- Logo -->
                                <a  href="<?php echo base_url() . 'Con_dashbord' ?>">
                                    <img src="<?php echo base_url(); ?>assets/img/5412.jpg" alt="Logo" height="50px;">
                                </a>				
                            </div>
                            
                            <div class="col-md-6 ">
                                <div class = "btn-group pull-right user-option" >
                                    <a href="" class = "dropdown-toggle" data-toggle = "dropdown"><i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;
                                        <?php echo $username; ?>&nbsp;&nbsp;
                                        <span class = "caret"></span>
                                    </a>
                                    <ul class = "dropdown-menu">
                                        <li><a href = "#"><i class="fa fa-cogs"></i>Settings</a></li>
                                        <li><a href = "#"><i class="fa fa-eye"></i>View Profile</a></li>
                                        <li><a href = "#"><i class="fa fa-key"></i>Change Password</a></li>
                                        <li><a href = "<?php echo base_url() . 'index.php/chome/logout' ?>"><i class="fa fa-sign-out"></i>Log Out</a></li>
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div><!--/end container-->
				
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse mega-menu navbar-responsive-collapse">
                    <div class="container">
                        <div class="row">						
                            <!-- Top Menu -->
                            <ul class="nav navbar-nav">
                                <!-- class="dropdown active" -->
                                <!--<li><a href="<?php // echo base_url().'chome/ahome'  ?>">Home</a></li>-->
                                <li><a href="<?php echo base_url() . 'Con_dashbord' ?>" >Dashboard</a></li>
                                <li><a href="#" >Self Service</a></li>
                                <li><a href="#" >Service Request</a></li>
                                <li><a href="<?php echo base_url() . 'con_Employees' ?>" >HR</a></li>
                                <li><a href="#" >Appraisals</a></li>
                                <li><a href="#" >Organization</a></li>
                                <li><a href="#" >Analytics</a></li>
                                <li><a href="#" >Modules</a></li>
                                <li><a href="#" >Time</a></li>
                                <!-- <li class="dropdown">
                                        <a href="javascript:void(0);" >User</a>
                                        <ul class="dropdown-menu" >
                                                <li><a href="<?php //echo base_url() . 'index.php/chome/logout' ?>">Logout</a></li>
                                        </ul>
                                </li>-->

                            </ul>
                            <!-- End Top Menu -->
                        </div>
                    </div><!--/end container-->
                </div><!--/navbar-collapse-->
            </div>
            <!--=== End Header ===-->
           
