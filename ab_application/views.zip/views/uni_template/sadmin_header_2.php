<?php
    $log_data = $this->session->userdata('hr_logged_in'); 
    $username=$log_data['name'];
    $userid=$log_data['id'];
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
    <head>
        <title><?php echo $title; ?></title>

        <!-- Meta -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- Favicon -->
	<link rel="icon" type="image/ico" href="<?php echo base_url(); ?>assets/img/icon.ico"/>
        
        <!-- Web Fonts -->
        <link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

        <!-- CSS Global Compulsory -->
        <link rel="stylesheet"  href="<?php echo base_url(); ?>assets/plugins/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">

        <!-- CSS Header and Footer -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/headers/header-default.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/footers/footer-v1.css">
          
        <!-- CSS Implementing Plugins -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/animate.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/line-icons/line-icons.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/font-awesome/css/font-awesome.min.css">
        <!--<link rel="stylesheet" href="assets/plugins/owl-carousel/owl-carousel/owl.carousel.css">-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/sky-forms-pro/skyforms/css/sky-forms.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/sky-forms-pro/skyforms/custom/custom-sky-forms.css">
        <!--[if lt IE 9]><link rel="stylesheet" href="assets/plugins/sky-forms-pro/skyforms/css/sky-forms-ie8.css"><![endif]-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/hover-effects/css/custom-hover-effects.css">

        <!-- CSS Page Style -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/pages/page_search.css">

        <!-- CSS Theme -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/theme-colors/default.css" id="style_color">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/theme-skins/dark.css">

        <!-- CSS Customization -->
       
        <link href="<?php echo base_url(); ?>assets/css/select2.css" rel="stylesheet"/>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/image-hover/css/img-hover.css">
        <!-- CSS log-in -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/login.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/magic/magic.css" />
        <!-- data table -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/dataTables/dataTables.bootstrap.css" />
        <!-- JS -->
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/sky-forms-pro/skyforms/js/jquery.validate.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/validation.js"></script>
        <!-- select 2 -->
        <script src="<?php echo base_url(); ?>assets/js/select2.js"></script> 
        <!-- Time Picker-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/timepicker/bootstrap-timepicker.css" type="text/css" media="screen">
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/timepicker/bootstrap-timepicker.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.chained.min.js"></script>
        
        <script src="<?php echo base_url()?>assets/js/ajaxfileupload.js"></script>
        
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/slicknav.min.css">
        
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/custom.css">
        
        <script type="text/javascript">
            
//            function updateClock ( )
//            {
//                var currentTime = new Date ( );
//                var currentHours = currentTime.getHours ( );
//                var currentMinutes = currentTime.getMinutes ( );
//                var currentSeconds = currentTime.getSeconds ( );
//
//                // Pad the minutes and seconds with leading zeros, if required
//                currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
//                currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
//
//                // Choose either "AM" or "PM" as appropriate
//                var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
//
//                // Convert the hours component to 12-hour format if needed
//                currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
//
//                // Convert an hours component of "0" to "12"
//                currentHours = ( currentHours == 0 ) ? 12 : currentHours;
//
//                // Compose the string for display
//                var currentTimeString = currentHours + ":" + currentMinutes + ":" + currentSeconds + " " + timeOfDay;
//
//
//                $("#clock").html(currentTimeString);
//
//            }

//            $(document).ready(function()
//            {
//                setInterval('updateClock()', 1000);
//            });
		
        </script>
        
    </head>
    <body class="">
        <div class="wrapper">
            <!--=== Header ===-->
            <div class="header">
                <div class="top-bar">
                    <div class="container">
                        <div class="row ">

                            <div class="col-md-1">
                                <!-- Logo -->
                                <a  href="<?php echo base_url() . 'Con_dashbord' ?>">
                                    <img src="<?php echo base_url(); ?>assets/img/5412.jpg" alt="Logo" height="50px;">
                                </a>				
                            </div>
                            <div class="col-md-3">
                                <div class="app-title">
                                    <h2 style="color: #444;" class="text-primary"> HR Management System </h2>
                                </div>			
                            </div>
                            <div class="col-md-6">
                                <!--<div id="clock" class="pull-right" style="margin-top: 15px;"></div>-->
                            </div>
                       <!-- <div class="col-md-3">
                                <div class="container">
                                    <div class="row pull-right padding-top-5">
                                        <div class="search">
                                            <input type="text" class="form-control input-sm" maxlength="64" placeholder="Search" />
                                            <button type="submit" class="btn btn-default btn-sm srbtn">Search</button>
                                        </div>
                                    </div>
                                </div>
                            </div>-->
                            <div class="col-md-2">
                                <div class = " row btn-group pull-right user-option">
                                    <?php
                                    //echo $module_id;
                                    //if ($module_id != 0) {
                                        ?>
                                   <!-- <div class="configurewizard pull-left">
                                            <a class="btn btn-u" href="<?php //echo base_url() . 'Con_configaration'   ?>">Configuration Wizard</a>
                                        </div>-->
                                        <a href="" class = "dropdown-toggle" data-toggle = "dropdown"><i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;
                                            <?php echo $username; ?>&nbsp;&nbsp;
                                            <span class = "caret"></span>
                                        </a>
                                        <ul class = "dropdown-menu">
                                            <li><a href = "#"><i class="fa fa-cog"></i>Settings</a></li>
                                            <li><a href = "#"><i class="fa-li fa fa-spinner fa-spin"></i>Mail Settings</a></li>
                                            <li><a href = "<?php echo base_url() . "Con_User/edit_entry/" . $userid ?>"><i class="fa fa-eye"></i>View Profile</a></li>
                                            <li><a href = "#"><i class="fa fa-key"></i>Change Password</a></li>
                                            <li><a href = "<?php echo base_url() . 'index.php/chome/logout' ?>"><i class="fa fa-sign-out"></i>Log Out</a></li>
                                        </ul>
                                        <?php
                                    //} else {
                                        ?>
                                        <!--<div class="col-sm-12">
                                            <div class="configurewizard">
                                            <a class="btn btn-u" href="<?php //echo base_url() . 'Con_dashbord'   ?>">Configure Later</a>
                                            </div>
                                        </div>-->
                                        <?php
                                    //}
                                    ?>
                                </div>
                            </div>

                        </div>
                    </div>
                </div><!--/end container-->

                <?php
//                if ($module_id != 0) {
                    ?>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse mega-menu navbar-responsive-collapse ">
                        <div class="container">
                            <div class="row">						
                                <!-- Top Menu -->
                                <ul class="nav navbar-nav">
                                    <?php
                                    $user_data = $this->session->userdata('hr_logged_in');
                                    $user_module = $user_data ['user_module'];
                                    $user_module = explode(",", $user_module);
                                    $user_module = array_map('intval', $user_module);
                                    //print_r($user_module);

                                    $this->db->order_by("sequence", "asc");
                                    $this->db->where(array('status' => 1));
                                    $this->db->where_in('id', $user_module);
                                    $module_query = $this->db->get('main_module');

                                    foreach ($module_query->result() as $key):
                                        $module_link = base_url() . $key->module_link . '/' . 'index' . '/' . $key->id;
                                        ?>
                                        <li><a href="<?php echo $module_link; ?>" ><?php echo $key->module_name ?></a></li>
                                        <?php
                                    endforeach;
                                    ?>
                                </ul>
                                <!-- End Top Menu -->
                            </div>
                        </div><!--/end container-->
                    </div><!--/navbar-collapse-->
                    <?php
//                }
                ?>
            </div>
            <!--=== End Header ===-->
            <div class="col-md-10 col-md-offset-2 pull-right" id='messagebox' style=" font-size: 14px; text-align: center; position: absolute; z-index: 9999 !important;"> </div>
<?php 
if($module_id==0)
{
    ?>
    <div class="container content"> <!--/container-->
        <div class="row main-body"> <!--/row-->
<?php
   
}
?>