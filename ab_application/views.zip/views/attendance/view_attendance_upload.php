<div class="col-md-10 main-content-div">
    <div class="main-content">

        <div class="container conbre">
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url() . 'Con_TimeAndAttendance' ?>">HRM</a></li>
                <li class="active"><?php echo $page_header; ?></li>
            </ol>
        </div>

        <div class="container tag-box tag-box-v3" style="margin-top: 0px; padding-bottom: 15px;"> <!-- container well div -->
            <div id="signupbox" style=" margin-top:10px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                <form id="Attendence_Upload" name="sky-form11" class="form-horizontal" method="post" action="<?php echo base_url(); ?>Con_Attendence_Upload/save_Attendence_Upload" enctype="multipart/form-data" role="form">
                    <input type="hidden" value="" name="id"/>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">File Type<span class="req"/></label>
                        <div class="col-sm-8">                
                            <select name="upload_file_type" id="upload_file_type" class="col-sm-12 col-xs-12 myselect2 input-sm" >
                                <option></option>
                                <?php
                                $upload_file_type = array(1 => 'CSV', 2 => 'Excel', 3 => 'TEXT');
                                foreach ($upload_file_type as $key => $val):
                                    ?>
                                    <option value="<?php echo $key ?>"><?php echo $val ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"></label>
                        <div class="col-sm-8">
                            <a href="#" onclick="add_upload_file();" class="linkStyle" data-toggle="tooltip" title="Upload">
                                <button type="button" class="btn btn-u">Upload File</button>
                            </a>   
                            <input type="hidden" name="attendance_file_name" id="attendance_file_name" />
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" id="submit" class="btn btn-u">Process</button>
                        <a class="btn btn-danger" href="<?php echo base_url() . "Con_Attendence_Upload" ?>">Close</a>
                    </div>

                </form>
            </div>

        </div>

    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="attendence_file_Modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="myModalLabel">Add Document</h4>
            </div>
            <form id="attendence_file_form" name="sky-form11" class="form-horizontal" action="" method="post" enctype="multipart/form-data" role="form">
                <input type="hidden" value="" name="id_emp_languages"/>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="col-sm-4 control-label"> Select Document </label>
                        <div class="col-sm-8">
                            <input type="file" name="userfile" id="userfile" size="20" />
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="submit" class="btn btn-u">Upload</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


</div><!--/row-->
</div><!--/container-->


<script type="text/javascript">

    $("#upload_file_type").select2({
        placeholder: "Select File Type",
        allowClear: true,
    });
    
    var save_method; //for save method string
    function add_upload_file()
    {
        save_method = 'add';
        $('#attendence_file_form')[0].reset(); // reset form on modals
        $('#attendence_file_Modal').modal('show'); // show bootstrap modal
        $('.modal-title').text('Upload Document'); // Set Title to Bootstrap modal title
    }
    
    $(function() {
        $('#attendence_file_form').submit(function(e) {
            e.preventDefault();
            var base_url='<?php echo base_url(); ?>';
            $.ajaxFileUpload({
                url             :base_url + './Con_Attendence_Upload/Attendence_file_Upload/', 
                secureuri       :false,
                fileElementId   :'userfile',
                dataType    : 'JSON',
                success : function (data)
                {
                    var datas = data.split( '__' );
                    $('#attendance_file_name').val(datas[1]);
                    
                    var url = '';
                    view_message(datas[0],url,'attendence_file_Modal','attendence_file_form');

                }
            });
            return false;
        });
    });
    
    
     $(function(){
        $( "#Attendence_Upload" ).submit(function( event ) {
            var url = $(this).attr('action');
                $.ajax({
                url: url,
                data: $("#Attendence_Upload").serialize(),
                type: $(this).attr('method')
              }).done(function(data) {
                  
                    var url = '<?php echo base_url() ?>Con_Attendence_Upload';
                    view_message(data,url,'','');
                    
              });
            event.preventDefault();
        });
    });
    
</script>

