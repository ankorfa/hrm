<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Con_OrganizationStructure extends CI_Controller {
    
   

    public function __construct() {
        parent::__construct();
        
    }

    public function index() {
        //$this->menu_id = $this->uri->segment(3);
        //$this->Common_model->is_user_valid($this->user_id,$this->menu_id,$this->user_menu);
        
        $param['menu_id']=39;
        $param['page_header'] = "Organization Structure";
        $param['module_id']=1;
        
        $param['left_menu'] = 'sadmin/hrm_leftmenu.php';
        $param['content'] = 'hr/view_OrganizationStructure.php';
        $this->load->view('admin/home', $param);
    }
    
    

    //==========================================================================
    
    
}
